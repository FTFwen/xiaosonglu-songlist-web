// content.js - 直播间悬浮入口 + 弹幕输入桥
(function () {
  'use strict';

  const ROOM_ID_MATCH = location.href.match(/^https:\/\/live\.bilibili\.com\/(\d+)/i);
  const roomId = ROOM_ID_MATCH ? ROOM_ID_MATCH[1] : '';
  const roomKey = roomId === '31368705' ? 'miting' : roomId === '1727071052' ? 'xiaosonglu' : null;
  if (!roomKey) return;
  if (document.getElementById('__song_helper_bubble')) return;

  const STORAGE_KEYS = getStorageKeys(roomKey);
  const BUBBLE_SIZE = 52;
  const PANEL_WIDTH = 440;
  const PANEL_HEIGHT = 680;
  const EDGE_GAP = 16;
  const PANEL_GAP = 14;
  const DRAG_THRESHOLD = 6;
  const CLOSE_ANIM_MS = 180;

  // 扩展上下文是否仍有效（插件被重新加载后旧页面里的脚本会失效，静默跳过而非报错）
  function extensionContextAlive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  }

  let panelVisible = false;
  let dragging = false;
  let moved = false;
  let pointerId = null;
  let dragOffsetX = 0;
  let dragOffsetY = 0;
  let dragStartLeft = 0;
  let dragStartTop = 0;
  let bubblePos = null;
  let closeTimer = null;

  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  function viewportWidth() {
    return window.innerWidth || document.documentElement.clientWidth || 1280;
  }

  function viewportHeight() {
    return window.innerHeight || document.documentElement.clientHeight || 720;
  }

  function getDefaultBubblePosition() {
    return {
      left: Math.max(EDGE_GAP, viewportWidth() - BUBBLE_SIZE - 24),
      top: Math.max(EDGE_GAP, viewportHeight() - BUBBLE_SIZE - 122)
    };
  }

  function normalizeBubblePosition(pos) {
    const fallback = getDefaultBubblePosition();
    const left = clamp(Number(pos && pos.left), EDGE_GAP, Math.max(EDGE_GAP, viewportWidth() - BUBBLE_SIZE - EDGE_GAP));
    const top = clamp(Number(pos && pos.top), EDGE_GAP, Math.max(EDGE_GAP, viewportHeight() - BUBBLE_SIZE - EDGE_GAP));
    return {
      left: Number.isFinite(left) ? left : fallback.left,
      top: Number.isFinite(top) ? top : fallback.top
    };
  }

  function applyBubblePosition(pos) {
    bubblePos = normalizeBubblePosition(pos);
    bubble.style.left = `${bubblePos.left}px`;
    bubble.style.top = `${bubblePos.top}px`;
    bubble.style.right = 'auto';
    bubble.style.bottom = 'auto';
    if (panelVisible) updatePanelPosition();
  }

  function saveBubblePosition() {
    if (!extensionContextAlive()) return;
    try {
      chrome.storage.local.set({ [STORAGE_KEYS.bubblePosition]: bubblePos });
    } catch (e) { /* 上下文失效时静默忽略 */ }
  }

  function loadBubblePosition() {
    if (!extensionContextAlive()) return;
    chrome.storage.local.get([STORAGE_KEYS.bubblePosition], result => {
      applyBubblePosition(result[STORAGE_KEYS.bubblePosition] || getDefaultBubblePosition());
    });
  }

  function findChatInput() {
    const selectors = [
      '.chat-input-area textarea',
      '#chat-control-panel-vm textarea',
      '.live-message-wrap textarea',
      'textarea.chat-input',
      '[placeholder*="弹幕"]',
      '[placeholder*="说点什么"]',
      'textarea'
    ];

    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el && el.offsetParent !== null) return el;
    }

    const editables = document.querySelectorAll('[contenteditable="true"]');
    for (const el of editables) {
      if (el.offsetParent !== null) return el;
    }

    return null;
  }

  function setNativeInputValue(el, value) {
    const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor && descriptor.set) descriptor.set.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    if (typeof el.setSelectionRange === 'function') {
      el.setSelectionRange(value.length, value.length);
    }
  }

  function typeInChatInput(text) {
    const input = findChatInput();
    if (!input) return false;

    input.focus();
    if (input.tagName === 'TEXTAREA' || input.tagName === 'INPUT') {
      setNativeInputValue(input, text);
      return true;
    }

    input.textContent = text;
    input.dispatchEvent(new InputEvent('input', { bubbles: true, data: text }));
    return true;
  }

  function getPanelMetrics() {
    const maxWidth = Math.min(PANEL_WIDTH, viewportWidth() - EDGE_GAP * 2);
    const maxHeight = Math.min(PANEL_HEIGHT, viewportHeight() - EDGE_GAP * 2);
    return { width: maxWidth, height: maxHeight };
  }

  function updatePanelPosition() {
    const rect = bubble.getBoundingClientRect();
    const vw = viewportWidth();
    const vh = viewportHeight();
    const { width, height } = getPanelMetrics();
    const bubbleCenterX = rect.left + rect.width / 2;
    const bubbleCenterY = rect.top + rect.height / 2;

    let left;
    let horizontal = 'right';
    if (bubbleCenterX > vw / 2) {
      left = rect.right - width;
      horizontal = 'right';
    } else {
      left = rect.left;
      horizontal = 'left';
    }
    left = clamp(left, EDGE_GAP, vw - width - EDGE_GAP);

    const spaceBelow = vh - rect.bottom - PANEL_GAP;
    const spaceAbove = rect.top - PANEL_GAP;
    let top;
    let vertical = 'above';
    if (spaceBelow >= height || spaceBelow >= spaceAbove) {
      top = rect.bottom + PANEL_GAP;
      vertical = 'below';
    } else {
      top = rect.top - height - PANEL_GAP;
      vertical = 'above';
    }
    top = clamp(top, EDGE_GAP, vh - height - EDGE_GAP);

    panel.style.width = `${width}px`;
    panel.style.height = `${height}px`;
    panel.style.left = `${left}px`;
    panel.style.top = `${top}px`;
    panel.dataset.side = horizontal;
    panel.dataset.vertical = vertical;

    const originX = horizontal === 'right' ? '100%' : '0%';
    const originY = vertical === 'below' ? '0%' : '100%';
    panel.style.setProperty('--panel-origin', `${originX} ${originY}`);
  }

  function openPanel() {
    clearTimeout(closeTimer);
    updatePanelPosition();
    panelVisible = true;
    panel.style.display = 'block';
    requestAnimationFrame(() => {
      panel.classList.remove('closing');
      panel.classList.add('open');
      bubble.classList.add('active');
    });
  }

  function closePanel() {
    if (!panelVisible) return;
    panelVisible = false;
    panel.classList.remove('open');
    panel.classList.add('closing');
    bubble.classList.remove('active');
    clearTimeout(closeTimer);
    closeTimer = setTimeout(() => {
      panel.style.display = 'none';
      panel.classList.remove('closing');
    }, CLOSE_ANIM_MS);
  }

  function togglePanel() {
    if (panelVisible) closePanel();
    else openPanel();
  }

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'typeInChat') {
      const ok = typeInChatInput(request.text || '');
      sendResponse(ok ? { success: true } : { success: false, error: '未找到直播间输入框' });
      return true;
    }
    return false;
  });

  const style = document.createElement('style');
  // 小松绿房间：气泡用专属图片（透明圆形贴纸），其他房间保持 🎵 默认风格
  const xiaosongluBubbleCss = roomKey === 'xiaosonglu' ? `
    #__song_helper_bubble.room-xiaosonglu {
      border-radius: 50%;
      border: 2px solid rgba(255,255,255,0.92);
      background: url('${chrome.runtime.getURL('assets/xiaosonglu-bubble.png')}') center/cover no-repeat, linear-gradient(135deg, #8a9a4e, #6f7d3d);
      box-shadow: 0 10px 26px rgba(110, 124, 66, 0.5);
    }
    #__song_helper_bubble.room-xiaosonglu:hover {
      box-shadow: 0 14px 32px rgba(110, 124, 66, 0.62);
    }` : '';
  style.textContent = `
    #__song_helper_bubble {
      position: fixed;
      left: 0;
      top: 0;
      width: ${BUBBLE_SIZE}px;
      height: ${BUBBLE_SIZE}px;
      border-radius: 18px;
      border: none;
      z-index: 2147483600;
      background: linear-gradient(135deg, #6d7cf0, #7b57c7);
      color: #fff;
      font-size: 22px;
      box-shadow: 0 10px 28px rgba(77, 91, 191, 0.4);
      cursor: grab;
      user-select: none;
      touch-action: none;
      transition: transform .18s ease, box-shadow .18s ease, opacity .18s ease;
    }${xiaosongluBubbleCss}
    #__song_helper_bubble:hover {
      transform: translateY(-2px) scale(1.04);
      box-shadow: 0 14px 32px rgba(77, 91, 191, 0.48);
    }
    #__song_helper_bubble.active {
      transform: scale(.96);
    }
    #__song_helper_bubble.dragging {
      cursor: grabbing;
      transform: scale(1.03);
      box-shadow: 0 18px 36px rgba(77, 91, 191, 0.5);
    }
    #__song_helper_panel {
      --panel-origin: 100% 100%;
      display: none;
      position: fixed;
      z-index: 2147483599;
      border-radius: 18px;
      overflow: hidden;
      box-shadow: 0 18px 48px rgba(32, 42, 92, 0.2);
      border: 1px solid rgba(181, 196, 255, 0.8);
      background: #eef3ff;
      transform-origin: var(--panel-origin);
      opacity: 0;
      transform: scale(0.92);
      transition: opacity ${CLOSE_ANIM_MS}ms ease, transform ${CLOSE_ANIM_MS}ms ease;
      pointer-events: none;
    }
    #__song_helper_panel.open {
      opacity: 1;
      transform: scale(1);
      pointer-events: auto;
    }
    #__song_helper_panel.closing {
      opacity: 0;
      transform: scale(0.94);
      pointer-events: none;
    }
    #__song_helper_panel iframe {
      width: 100%;
      height: 100%;
      border: none;
      background: #eef3ff;
    }
  `;
  document.head.appendChild(style);

  const bubble = document.createElement('button');
  bubble.id = '__song_helper_bubble';
  bubble.type = 'button';
  bubble.textContent = '🎵';
  bubble.title = roomKey === 'miting' ? '打开米汀歌单助手' : '打开小松绿歌单助手';
  // 小松绿：气泡用专属图片，去掉默认音符字符
  if (roomKey === 'xiaosonglu') {
    bubble.classList.add('room-xiaosonglu');
    bubble.textContent = '';
  }

  const panel = document.createElement('div');
  panel.id = '__song_helper_panel';
  const iframe = document.createElement('iframe');
  iframe.src = chrome.runtime.getURL(`popup.html?embedded=1&roomKey=${encodeURIComponent(roomKey)}&roomId=${encodeURIComponent(roomId)}`);
  iframe.setAttribute('title', '歌单助手');
  // 跨域 iframe 默认被 Permissions Policy 拦截 Clipboard API，
  // 显式授予 clipboard-write 权限，否则复制/导出功能在悬浮面板内不可用
  iframe.setAttribute('allow', 'clipboard-write');
  panel.appendChild(iframe);

  bubble.addEventListener('pointerdown', event => {
    pointerId = event.pointerId;
    moved = false;
    dragging = true;
    dragStartLeft = bubblePos.left;
    dragStartTop = bubblePos.top;
    dragOffsetX = event.clientX - bubblePos.left;
    dragOffsetY = event.clientY - bubblePos.top;
    bubble.classList.add('dragging');
    bubble.setPointerCapture(pointerId);
  });

  bubble.addEventListener('pointermove', event => {
    if (!dragging || event.pointerId !== pointerId) return;
    const nextLeft = clamp(event.clientX - dragOffsetX, EDGE_GAP, viewportWidth() - BUBBLE_SIZE - EDGE_GAP);
    const nextTop = clamp(event.clientY - dragOffsetY, EDGE_GAP, viewportHeight() - BUBBLE_SIZE - EDGE_GAP);
    if (Math.abs(nextLeft - dragStartLeft) > DRAG_THRESHOLD || Math.abs(nextTop - dragStartTop) > DRAG_THRESHOLD) {
      moved = true;
    }
    applyBubblePosition({ left: nextLeft, top: nextTop });
  });

  function endDrag(event) {
    if (!dragging || event.pointerId !== pointerId) return;
    dragging = false;
    bubble.classList.remove('dragging');
    try { bubble.releasePointerCapture(pointerId); } catch (err) { /* ignore */ }
    saveBubblePosition();
    if (!moved) {
      togglePanel();
    }
    pointerId = null;
  }

  bubble.addEventListener('pointerup', endDrag);
  bubble.addEventListener('pointercancel', endDrag);

  window.addEventListener('resize', () => {
    applyBubblePosition(bubblePos || getDefaultBubblePosition());
  });

  document.body.appendChild(panel);
  document.body.appendChild(bubble);
  applyBubblePosition(getDefaultBubblePosition());
  loadBubblePosition();
})();