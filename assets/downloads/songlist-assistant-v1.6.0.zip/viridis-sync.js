// viridis-sync.js - viridis.love 页面与插件的中意数据同步桥
// 读取/写入网页 localStorage 里的中意存档（favorites:shared），
// 与插件（chrome.storage）保持同一份数据
(() => {
  'use strict';

  const KEY = 'favorites:shared';

  function readWebFavorites() {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function writeWebFavorites(data) {
    try {
      localStorage.setItem(KEY, JSON.stringify(data));
    } catch (e) { /* 存储满或不可用时忽略 */ }
  }

  // 网页 → 插件：初始推送 + 本地存储变化时推送
  function pushToPlugin() {
    try {
      chrome.runtime.sendMessage({ type: 'WEB_FAVORITES_SYNC', data: readWebFavorites() });
    } catch (e) { /* 后台不可用时忽略 */ }
  }

  window.addEventListener('storage', event => {
    if (event.key === KEY) pushToPlugin();
  });

  // 同页操作（网页脚本写入中意后派发的自定义事件，storage 事件只跨标签页触发）
  window.addEventListener('favorites:shared:changed', () => pushToPlugin());

  // 插件 → 网页：收到插件中意变化，写回网页 localStorage
  // 或：插件主动查询网页当前中意（实时拉取，不依赖 background 缓存）
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request && request.type === 'PLUGIN_FAVORITES_SYNC') {
      writeWebFavorites(request.data);
      if (sendResponse) sendResponse({ ok: true });
      return true;
    }
    if (request && request.type === 'GET_WEB_FAVORITES_PAGE') {
      sendResponse({ data: readWebFavorites() });
      return true;
    }
    return false;
  });

  pushToPlugin();
})();
