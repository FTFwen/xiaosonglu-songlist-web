// background.js - 弹幕输入桥 + 中意数据同步中转
// 中意同步：viridis.love 页面的中意（localStorage favorites:shared）
// 与插件（chrome.storage 'webFavorites'）双向同步，两边共用同一份数据

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // 网页 → 插件：存一份到插件本地
  if (request && request.type === 'WEB_FAVORITES_SYNC') {
    chrome.storage.local.set({ webFavorites: request.data || {} }, () => {
      if (sendResponse) sendResponse({ ok: true });
    });
    return true;
  }

  // 插件读取网页中意
  if (request && request.type === 'GET_WEB_FAVORITES') {
    chrome.storage.local.get(['webFavorites'], result => {
      sendResponse({ data: result.webFavorites || null });
    });
    return true;
  }

  // 插件 → 网页：把插件中意写回 viridis.love 页面 localStorage
  if (request && request.type === 'PLUGIN_FAVORITES_SYNC') {
    chrome.tabs.query({ url: 'https://viridis.love/*' }, tabs => {
      (tabs || []).forEach(tab => {
        try {
          chrome.tabs.sendMessage(tab.id, { type: 'PLUGIN_FAVORITES_SYNC', data: request.data });
        } catch (e) { /* 页面未就绪忽略 */ }
      });
      if (sendResponse) sendResponse({ ok: true });
    });
    return true;
  }

  if (request.action !== 'typeInChat') {
    return false;
  }

  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const tab = tabs && tabs[0];
    if (!tab || !tab.id) {
      sendResponse({ success: false, error: '没有找到当前活动标签页' });
      return;
    }

    // 只向受支持直播间转发（米汀 31368705 / 小松绿 1727071052）
    const url = String(tab.url || '');
    const roomMatch = url.match(/^https:\/\/live\.bilibili\.com\/(31368705|1727071052)/i);
    if (!roomMatch) {
      sendResponse({ success: false, error: '请先打开受支持的直播间（米汀 31368705 或小松绿 1727071052）' });
      return;
    }

    chrome.tabs.sendMessage(tab.id, { action: 'typeInChat', text: request.text || '' }, response => {
      if (chrome.runtime.lastError) {
        sendResponse({ success: false, error: '直播间页面未就绪，请刷新后重试' });
        return;
      }
      sendResponse(response && response.success ? response : { success: false, error: '直播间脚本未准备好' });
    });
  });

  return true;
});
