// popup.js - 多房间歌单助手

const SONG_CACHE_TTL = 30 * 60 * 1000;
const HISTORY_CACHE_TTL = 30 * 60 * 1000;
// 中意存档跨直播间共享（单一全局存档；各房间展示时按本房间歌单过滤）
const FAVORITES_KEY = 'favorites:shared';

const state = {
  activeTab: null,
  activeRoomContext: { roomKey: null, roomId: null, supported: false },
  currentRoomKey: 'miting',
  currentRoom: getRoomConfig('miting'),
  settings: {
    lastRoomKey: 'miting',
    roomSettings: {},
    orderFormat: 'name',          // 点歌文案格式：name = 前缀+歌名；auto = 前缀+歌名+版本/歌手
    defaultSearchMode: 'mixed',   // 默认搜索模式：mixed / song / artist
    defaultSortField: 'last_sing_at', // 默认排序字段
    defaultSortDir: 'desc',       // 默认排序方向
    onlySungSongs: true           // 歌单只显示唱过的歌
  },
  searchMode: 'mixed',
  filtersVisible: false,
  favoritesOnly: false,
  allSongs: [],
  filteredSongs: [],
  favoritesMap: {},
  favoriteList: [],
  favoritesImportVisible: false,
  selectedSong: null,
  callwords: [],
  isSongLoading: false,
  songDataUpdatedAt: null,
  songDataFromCache: false,
  detailsCache: {},
  historyMeta: null,
  historyEntries: [],
  historyPage: 1,
  historyTotalPages: 1,
  historySelectedDate: null,
  isHistoryLoading: false,
  songFilters: {
    query: '',
    countMin: null,
    countMax: null,
    daysMin: null,
    daysMax: null,
    languages: [],
    tags: [],
    sortField: 'last_sing_at',
    sortDir: 'desc'
  },
  audioIndex: null,   // 歌曲 → 音频路径映射（播放器用）
  cutInfo: null       // 歌曲 → 歌切标题映射
};

const dom = {};

function $(id) {
  return document.getElementById(id);
}

function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function getSongCutUrl(value) {
  const text = String(value || '').trim();
  if (!text) return '';
  if (/^https?:\/\//i.test(text)) return text;
  const match = text.match(/(BV[0-9A-Za-z]+)/i);
  return match ? `https://www.bilibili.com/video/${match[1]}/` : text;
}

function showToast(message, duration = 2200) {
  const toast = dom.toast;
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => toast.classList.remove('show'), duration);
}

function setHeaderStatus(text, cls = '') {
  dom.headerStatus.textContent = text;
  dom.headerStatus.className = `status-pill${cls ? ` ${cls}` : ''}`;
}

function setSourceBadge(text) {
  dom.sourceBadge.textContent = text;
}

function formatTone(tone) {
  if (tone === null || tone === undefined || tone === '') return '';
  const num = Number(tone);
  if (Number.isFinite(num)) {
    if (num > 0) return `+${num}`;
    return `${num}`;
  }
  return String(tone);
}

function normalizeTone(tone) {
  if (tone === null || tone === undefined || tone === '') return null;
  const num = Number(tone);
  return Number.isFinite(num) ? num : null;
}

function getDaysAgo(dateText) {
  if (!dateText) return null;
  const d = new Date(dateText);
  if (Number.isNaN(d.getTime())) return null;
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const then = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  return Math.floor((start - then) / 86400000);
}

function formatLastSing(dateText) {
  if (!dateText) return '—';
  const days = getDaysAgo(dateText);
  if (days === null) return dateText;
  if (days === 0) return '今天';
  if (days === 1) return '昨天';
  if (days < 7) return `${days} 天前`;
  if (days < 30) return `${Math.floor(days / 7)} 周前`;
  return dateText;
}

const INTERNAL_STATUS_LABELS = new Set([
  '歌切直补',
  '待原始回放定位',
  '待后续回放时间定位',
  '歌切合集补录',
  '自动识别待人工复核'
]);

const INTERNAL_TYPE_LABELS = new Set([
  '歌切补录'
]);

function splitStatusLabels(text) {
  return String(text || '')
    .split(/[、,，]/)
    .map(item => item.trim())
    .filter(Boolean);
}

function splitTypeLabels(text) {
  return String(text || '')
    .split(/[、,，/／|｜]/)
    .map(item => item.trim())
    .filter(Boolean);
}

function isInternalStatusLabel(label) {
  const text = String(label || '').trim();
  if (!text) return false;
  if (INTERNAL_STATUS_LABELS.has(text)) return true;
  // 含识歌流水线关键词的一律不展示（自动识别/待复核/回放定位/歌切补录等），
  // 这些是内部处理标记，不是给用户看的信息
  return /自动识别|待人工复核|待复核|回放定位|歌切直补|歌切补录|合集补录/.test(text);
}

function getVisibleStatusLabels(value) {
  const labels = Array.isArray(value) ? value : splitStatusLabels(value);
  return labels.filter(label => !isInternalStatusLabel(label));
}

function getVisibleTypeLabels(value) {
  return splitTypeLabels(value)
    .filter(label => !INTERNAL_TYPE_LABELS.has(label))
    .slice(0, 5);
}

function getVisibleTypeLabel(value) {
  return getVisibleTypeLabels(value).join('、');
}

function getVisibleStatusText(value) {
  return getVisibleStatusLabels(value).join('、');
}

function getLanguageBadgeClass(lang) {
  if (lang === '中文') return 'lang-zh';
  if (lang === '日语') return 'lang-ja';
  if (lang === '英语') return 'lang-en';
  if (lang === '粤语') return 'lang-cantonese';
  return 'lang-other';
}

function copyToClipboard(text) {
  // 悬浮面板 iframe 嵌入在 B 站页面（跨域），Clipboard API 会被 Permissions Policy
  // 拦截（即使 iframe 加了 allow 也不总是可靠），且会向控制台抛错。
  // 因此 embedded 模式直接走 execCommand 兜底（按钮点击时 iframe 有焦点，可用且无报错）；
  // 工具栏弹窗等顶层页面才用 Clipboard API。
  const embedded = new URLSearchParams(location.search).get('embedded') === '1';
  if (embedded) return Promise.resolve(fallbackCopy(text));
  return navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
}

function fallbackCopy(text) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.setAttribute('readonly', '');
  ta.style.position = 'fixed';
  ta.style.left = '-9999px';
  ta.style.top = '0';
  document.body.appendChild(ta);
  let ok = false;
  try {
    ta.select();
    ok = document.execCommand('copy');
  } catch (err) {
    ok = false;
  }
  document.body.removeChild(ta);
  return ok;
}

function storageGet(keys) {
  return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}

function storageSet(obj) {
  return new Promise(resolve => chrome.storage.local.set(obj, resolve));
}

async function getActiveTab() {
  return new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => resolve(tabs && tabs[0] ? tabs[0] : null));
  });
}

async function loadGlobalSettings() {
  const result = await storageGet(['settings:global']);
  const saved = result['settings:global'];
  if (saved && typeof saved === 'object') {
    state.settings = {
      lastRoomKey: saved.lastRoomKey || 'miting',
      roomSettings: saved.roomSettings || {},
      orderFormat: saved.orderFormat || 'name',
      defaultSearchMode: saved.defaultSearchMode || 'mixed',
      defaultSortField: saved.defaultSortField || 'last_sing_at',
      defaultSortDir: saved.defaultSortDir || 'desc',
      onlySungSongs: saved.onlySungSongs !== false
    };
  }
}

async function saveGlobalSettings() {
  await storageSet({ 'settings:global': state.settings });
}

function populateRoomSelect() {
  dom.roomSelect.innerHTML = ROOM_ORDER.map(key => {
    const config = getRoomConfig(key);
    return `<option value="${config.key}">${escHtml(config.name)}（${config.roomId}）</option>`;
  }).join('');
}

function renderRoomContextSummary() {
  const active = state.activeRoomContext;
  const current = state.currentRoom;
  const currentLabel = `${current.name} · 房间 ${current.roomId}`;
  let extra = current.subtitle;

  if (active.supported) {
    const activeConfig = getRoomConfig(active.roomKey);
    extra = `当前直播间已识别：${activeConfig.name}（${active.roomId}）`;
  } else if (state.activeTab && state.activeTab.url && state.activeTab.url.includes('live.bilibili.com')) {
    extra = '当前直播间不在支持列表里，仍可手动切换浏览已配置歌单。';
  } else {
    extra = '当前页不是受支持的直播间，可以先浏览歌单，点歌时会自动复制到剪贴板。';
  }

  dom.roomSubtitle.textContent = `${currentLabel} · ${extra}`;
  setSourceBadge(`数据源：${current.sourceLabel}`);
}

function getSongSearchText(song, mode) {
  const name = `${song.display_song_name || ''} ${song.song_name || ''} ${song.search_name || ''} ${song.row_key || ''}`.toLowerCase();
  const artist = `${song.artist || ''} ${song.artist_search || ''} ${song.feat_artist || ''}`.toLowerCase();
  const version = `${song.display_version || ''} ${song.type || ''} ${song.remark || ''}`.toLowerCase();
  if (mode === 'song') return `${name} ${version}`;
  if (mode === 'artist') return `${artist} ${version}`;
  return `${name} ${artist} ${version}`;
}

function dedupeSongs(rows) {
  const map = new Map();
  rows.forEach((row, index) => {
    const song = normalizeRoomSong(row, index);
    const key = song.song_name || song.row_key || String(song.song_id || index);
    if (!map.has(key)) {
      map.set(key, song);
      return;
    }
    const existing = map.get(key);
    const mergedStatuses = new Set([...splitStatusLabels(existing.status_labels), ...splitStatusLabels(song.status_labels)]);
    existing.status_labels = Array.from(mergedStatuses).join('、');
    if (!existing.last_sing_at || (song.last_sing_at && song.last_sing_at > existing.last_sing_at)) {
      existing.last_sing_at = song.last_sing_at;
    }
    if ((song.sing_count || 0) > (existing.sing_count || 0)) {
      existing.sing_count = song.sing_count;
    }
    if (!existing.identification && song.identification) existing.identification = song.identification;
  });
  return Array.from(map.values());
}

function getLocalResourceUrl(resourcePath) {
  return chrome.runtime.getURL(resourcePath);
}

async function fetchLocalJson(resourcePath, fallbackPath) {
  // 远程 http(s) URL 直接拉取；插件内置相对路径走 chrome.runtime.getURL；
  // 远程拉取失败时回退到插件内置的本地副本（fallbackPath）
  const isRemote = /^https?:\/\//i.test(String(resourcePath || ''));
  const url = isRemote ? resourcePath : getLocalResourceUrl(resourcePath);
  try {
    const resp = await fetch(url, { cache: 'no-cache' });
    if (!resp.ok) throw new Error(`数据文件读取失败（HTTP ${resp.status}）`);
    return await resp.json();
  } catch (error) {
    if (isRemote && fallbackPath) {
      const fallbackResp = await fetch(getLocalResourceUrl(fallbackPath), { cache: 'no-cache' });
      if (!fallbackResp.ok) throw error;
      return await fallbackResp.json();
    }
    throw error;
  }
}

function isJsonRoom(room) {
  return !!room && (room.sourceType === 'local-json' || room.sourceType === 'remote-json');
}

/* ===== 播放器（单曲播放/暂停，无播放列表） ===== */
const player = {
  audio: new Audio(),
  songId: null, // 当前播放歌曲的 song_id
};
player.audio.preload = 'auto';

function isPlayAborted(err) {
  return !!err && (err.name === 'AbortError' || /interrupted by a call to pause/i.test(err.message || ''));
}

function audioUrlOf(song) {
  if (!song || !state.audioIndex || !state.audioIndex.audios) return '';
  const key = song.row_key || song.song_name || '';
  const rel = state.audioIndex.audios[key];
  if (!rel) return '';
  return (state.currentRoom.audioBaseUrl || '') + rel;
}

async function loadAudioIndex() {
  const room = state.currentRoom;
  try {
    if (room.audioIndexDataUrl) {
      state.audioIndex = await fetchLocalJson(room.audioIndexDataUrl, room.audioIndexDataFallback);
    }
  } catch (err) {
    console.warn('[插件] 音频索引加载失败:', err.message);
    state.audioIndex = null;
  }
  try {
    if (room.cutInfoDataUrl) {
      state.cutInfo = await fetchLocalJson(room.cutInfoDataUrl, room.cutInfoDataFallback);
    }
  } catch (err) {
    console.warn('[插件] 歌切标题加载失败:', err.message);
    state.cutInfo = null;
  }
  if (state.allSongs.length) renderSongs();
}

// 歌切切片标题：优先歌切台账标题，兜底回放标题
function cutTitleOf(song) {
  if (!song || !state.cutInfo || !state.cutInfo.cuts) return '';
  const key = song.row_key || song.song_name || '';
  const info = state.cutInfo.cuts[key];
  return info && info.title ? info.title : '';
}

// 播放/暂停单曲：点正在播的歌 = 暂停/继续；点别的歌 = 切过去播放
function toggleSongPlay(song) {
  if (!song) return;
  const url = audioUrlOf(song);
  if (!url) { showToast('这首歌暂时没有收录音频'); return; }
  if (player.songId === song.song_id) {
    if (player.audio.paused) {
      player.audio.play().catch(err => { if (isPlayAborted(err)) return; showToast(`播放失败：${err.message || err}`); });
    } else {
      player.audio.pause();
    }
  } else {
    player.songId = song.song_id;
    player.audio.src = url;
    player.audio.play().catch(err => { if (isPlayAborted(err)) return; showToast(`播放失败：${err.message || err}`); });
  }
  updatePlayUI();
}

// 停止播放（取消选中时调用）
function stopPlay() {
  player.audio.pause();
  player.audio.removeAttribute('src');
  player.songId = null;
  updatePlayUI();
}

// 同步所有播放按钮（歌曲卡片 ▶/⏸ + 选中面板播放按钮）
function updatePlayUI() {
  const playing = player.songId != null && !player.audio.paused;
  document.querySelectorAll('.song-play-btn').forEach(btn => {
    const isCurrent = Number(btn.dataset.playSong) === player.songId;
    btn.classList.toggle('playing', isCurrent && playing);
    btn.textContent = isCurrent && playing ? '⏸' : '▶';
    btn.title = isCurrent && playing ? '暂停' : '播放音频';
  });
  const sel = state.selectedSong;
  const isSel = !!sel && player.songId === sel.song_id;
  if (dom.songPlayBtn) {
    dom.songPlayBtn.textContent = isSel && playing ? '⏸ 暂停' : '▶ 播放';
  }
}

player.audio.addEventListener('play', () => updatePlayUI());
player.audio.addEventListener('pause', () => updatePlayUI());
player.audio.addEventListener('ended', () => { player.songId = null; updatePlayUI(); });
player.audio.addEventListener('error', () => {
  showToast('音频加载失败，可能暂时没有收录');
  player.songId = null;
  updatePlayUI();
});

async function fetchSongPageData(config) {
  const mainResp = await fetch(config.songPageUrl, { cache: 'no-cache' });
  if (!mainResp.ok) throw new Error(`歌单页访问失败（HTTP ${mainResp.status}）`);
  const html = await mainResp.text();

  let dataFile = null;
  const scriptMatch = html.match(/<script\s+src="([^"]*\/public\/data\/readonly\/[^"]+\.js(?:\?[^"<>]*)?)"/i);
  if (scriptMatch) {
    dataFile = new URL(scriptMatch[1], config.songPageUrl).toString();
  }
  if (!dataFile) {
    const varMatch = html.match(/var\s+dataFile\s*=\s*'([^']+)'/i);
    if (varMatch) dataFile = new URL(varMatch[1], config.songPageUrl).toString();
  }
  if (!dataFile) throw new Error('没有找到歌单数据文件');

  const dataResp = await fetch(dataFile, { cache: 'no-cache' });
  if (!dataResp.ok) throw new Error(`歌单数据文件加载失败（HTTP ${dataResp.status}）`);
  const dataText = await dataResp.text();
  const match = dataText.match(/window\.__SONG_ALL_DATA__\s*=\s*(\[[\s\S]*\]);?\s*$/m);
  if (!match) throw new Error('无法解析歌单数据');
  const parsed = JSON.parse(match[1]);
  return dedupeSongs(parsed);
}

function paginateLocalHistory(entries, page, pageSize) {
  const total = Array.isArray(entries) ? entries.length : 0;
  const safeSize = Math.max(1, Number(pageSize) || 30);
  const totalPages = total ? Math.ceil(total / safeSize) : 1;
  const safePage = Math.min(Math.max(1, Number(page) || 1), totalPages);
  const start = (safePage - 1) * safeSize;
  return {
    page: safePage,
    totalPages,
    entries: entries.slice(start, start + safeSize)
  };
}

function mapLocalHistoryEntry(entry) {
  return {
    song_name: entry.song_name || '',
    sing_time: entry.sing_time || entry.start_time || '',
    statuses: Array.isArray(entry.statuses) ? entry.statuses : splitStatusLabels(entry.statuses),
    artist: entry.artist || '',
    replay_title: entry.replay_title || '',
    replay_url: entry.replay_url || '',
    cut_link: getSongCutUrl(entry.cut_link)
  };
}

async function getCachedSongs(roomKey) {
  const keys = getStorageKeys(roomKey);
  const result = await storageGet([keys.songCache, keys.songCacheTime]);
  const cache = result[keys.songCache];
  const time = result[keys.songCacheTime];
  if (!Array.isArray(cache) || !time) return null;
  if (Date.now() - time > SONG_CACHE_TTL) return null;
  return { songs: cache, time };
}

async function saveSongCache(roomKey, songs) {
  const keys = getStorageKeys(roomKey);
  await storageSet({
    [keys.songCache]: songs,
    [keys.songCacheTime]: Date.now()
  });
}

async function loadSongData(forceRefresh = false) {
  const roomKey = state.currentRoomKey;
  const room = state.currentRoom;
  state.isSongLoading = true;
  setHeaderStatus('歌单加载中…');

  // 默认只保留主播唱过的歌（sing_count > 0）；设置里关闭「只显示唱过的歌」后展示全部
  const keepSungSongs = songs => {
    const raw = Array.isArray(songs) ? songs : [];
    if (state.settings.onlySungSongs === false) return raw;
    return raw.filter(song => (Number(song.sing_count) || 0) > 0);
  };

  try {
    if (room.placeholder) {
      state.allSongs = [];
      state.filteredSongs = [];
      setHeaderStatus('空歌单占位', 'warn');
      renderSongs();
      return;
    }

    if (!forceRefresh) {
      const cached = await getCachedSongs(roomKey);
      if (cached) {
        if (state.currentRoomKey !== roomKey) return; // 已切换房间，丢弃过期结果
        state.allSongs = keepSungSongs(cached.songs);
        applySongFilters();
        setHeaderStatus('已读取缓存', 'ok');
        updateSongMetaText(new Date(cached.time), true);
        return;
      }
    }

    let songs;
    if (isJsonRoom(room) && room.songDataUrl) {
      const payload = await fetchLocalJson(room.songDataUrl, room.songDataFallback);
      songs = dedupeSongs(Array.isArray(payload.songs) ? payload.songs : []);
    } else {
      songs = await fetchSongPageData(room);
    }

    if (state.currentRoomKey !== roomKey) return; // 已切换房间，丢弃过期结果
    state.allSongs = keepSungSongs(songs);
    await saveSongCache(roomKey, songs); // 缓存原始数据，缓存命中时才能重新计算隐藏数
    applySongFilters();
    setHeaderStatus('歌单已更新', 'ok');
    updateSongMetaText(new Date(), false);
    showToast(`歌单已刷新，共 ${state.allSongs.length} 首`);
  } catch (error) {
    if (state.currentRoomKey !== roomKey) return;
    console.error('[歌单助手] 加载歌曲失败:', error);
    setHeaderStatus('歌单加载失败', 'err');
    renderSongs(error.message);
  } finally {
    state.isSongLoading = false;
  }
}

function updateSongMetaText(dateObj, fromCache) {
  state.songDataUpdatedAt = dateObj || null;
  state.songDataFromCache = !!fromCache;
  const count = state.filteredSongs.length;
  const total = state.allSongs.length;
  const stamp = state.songDataUpdatedAt ? state.songDataUpdatedAt.toLocaleString() : '未知时间';
  const cacheText = state.songDataFromCache ? '（缓存）' : '（最新）';
  dom.songMetaText.textContent = `当前 ${count} / ${total} 首 · 更新时间 ${stamp}${cacheText}`;
}

function applySongFilters() {
  const query = (dom.searchInput.value || '').trim().toLowerCase();
  state.songFilters.query = query;

  let rows = state.allSongs.slice();
  if (query) {
    rows = rows.filter(song => getSongSearchText(song, state.searchMode).includes(query));
  }

  rows = rows.filter(song => {
    if (state.songFilters.countMin !== null && (song.sing_count || 0) < state.songFilters.countMin) return false;
    if (state.songFilters.countMax !== null && (song.sing_count || 0) > state.songFilters.countMax) return false;

    const days = getDaysAgo(song.last_sing_at);
    if (state.songFilters.daysMin !== null) {
      if (days === null || days < state.songFilters.daysMin) return false;
    }
    if (state.songFilters.daysMax !== null) {
      if (days === null || days > state.songFilters.daysMax) return false;
    }

    if (state.songFilters.languages.length > 0 && !state.songFilters.languages.includes(song.language || '')) return false;
    if (state.songFilters.tags.length > 0) {
      const songTags = new Set(String(song.type || '').split(/[、,，/／|｜\s]+/).map(t => t.trim()).filter(Boolean));
      const hit = state.songFilters.tags.some(tag => songTags.has(tag));
      if (!hit) return false;
    }
    if (state.favoritesOnly && !state.favoritesMap[getFavoriteKey(song)]) return false;
    return true;
  });

  rows.sort((a, b) => compareSongs(a, b, state.songFilters.sortField, state.songFilters.sortDir));
  state.filteredSongs = rows;
  hydrateFavoriteList();

  renderSongs();
  renderFavorites();
  if (state.songDataUpdatedAt) {
    updateSongMetaText(state.songDataUpdatedAt, state.songDataFromCache);
  } else {
    updateSongMetaText(null, false);
  }
  syncFilterSummary();
}

function compareSongs(a, b, field, dir) {
  let va;
  let vb;
  if (field === 'sing_count') {
    va = Number(a.sing_count || 0);
    vb = Number(b.sing_count || 0);
  } else if (field === 'last_sing_at') {
    va = a.last_sing_at || '';
    vb = b.last_sing_at || '';
  } else if (field === 'artist') {
    va = (a.artist || '').toLowerCase();
    vb = (b.artist || '').toLowerCase();
  } else {
    va = (a.display_song_name || a.song_name || '').toLowerCase();
    vb = (b.display_song_name || b.song_name || '').toLowerCase();
  }
  if (va < vb) return dir === 'asc' ? -1 : 1;
  if (va > vb) return dir === 'asc' ? 1 : -1;
  return 0;
}

function getSongCardHtml(song) {
  const favoriteKey = getFavoriteKey(song);
  const favoriteActive = !!state.favoritesMap[favoriteKey];
  const statuses = getVisibleStatusLabels(song.status_labels);
  const identification = (song.identification || '').trim();
  const days = getDaysAgo(song.last_sing_at);
  const badges = [];
  const visibleTypes = getVisibleTypeLabels(song.type);
  const locked = isLockedSong(song);
  const banned = isBannedSong(song);

  if (song.language) badges.push(`<span class="badge ${getLanguageBadgeClass(song.language)}">${escHtml(song.language)}</span>`);
  if (song.display_version) badges.push(`<span class="badge">Ver. ${escHtml(song.display_version)}</span>`);
  visibleTypes.forEach(type => badges.push(`<span class="badge">${escHtml(type)}</span>`));
  if (identification) badges.push(`<span class="badge id ${banned ? 'banned' : locked ? 'locked' : ''}">${escHtml(identification)}</span>`);
  if (song.tone !== '' && song.tone !== null && song.tone !== undefined) badges.push(`<span class="badge tone">Tone ${escHtml(formatTone(song.tone))}</span>`);

  const statusHtml = statuses.map(item => `<span class="badge status">${escHtml(item)}</span>`).join('');
  const artistLine = [song.artist || '', song.feat_artist ? `feat. ${song.feat_artist}` : ''].filter(Boolean).join(' · ');
  const bottomLine = [
    song.last_sing_at ? `最近：${escHtml(formatLastSing(song.last_sing_at))}` : '最近：—',
    days === null ? '距今：—' : `距今：${days} 天`
  ].join(' · ');
  const cutUrl = getSongCutUrl(song.cut_link);
  const cutTitle = cutTitleOf(song);
  const cutLabel = cutTitle || '打开视频';
  const audioUrl = audioUrlOf(song);
  const nowPlaying = player.songId === song.song_id && !player.audio.paused;
  const playBtnHtml = audioUrl
    ? `<button class="song-play-btn${nowPlaying ? ' playing' : ''}" data-play-song="${song.song_id}" title="${nowPlaying ? '暂停' : '播放音频'}">${nowPlaying ? '⏸' : '▶'}</button>`
    : '';

  return `
    <div class="song-item${state.selectedSong && state.selectedSong.song_id === song.song_id ? ' selected' : ''}" data-song-id="${song.song_id}">
      <div class="song-top">
        <div class="song-main">
          <div class="song-name">${escHtml(song.display_song_name || song.song_name || '')}</div>
          <div class="song-sub">${escHtml(artistLine || '歌手未填写')}</div>
        </div>
        ${playBtnHtml}
        <button class="favorite-star${favoriteActive ? ' active' : ''}" data-favorite-key="${escHtml(favoriteKey)}" ${canFavoriteSong(song) ? '' : 'disabled'} title="${favoriteActive ? '取消中意' : '加入中意'}">★</button>
      </div>
      <div class="badge-wrap">
        <button class="badge count" data-detail-song="${escHtml(song.song_name || song.row_key || '')}" data-detail-label="${escHtml(song.display_song_name || song.song_name || '')}" data-detail-count="${escHtml(song.sing_count || 0)}">次数 ${escHtml(song.sing_count || 0)}</button>
        ${badges.join('')}
      </div>
      ${statuses.length ? `<div class="status-wrap">${statusHtml}</div>` : ''}
      <div class="song-bottom">
        <div class="song-bottom-left">
          <span>${escHtml(bottomLine)}</span>
        </div>
      </div>
      ${cutUrl ? `<div class="song-sub song-cut-row">歌切：<a href="${escHtml(cutUrl)}" target="_blank" rel="noreferrer" data-song-cut-link="${escHtml(cutUrl)}" title="${escHtml(cutTitle || cutUrl)}">${escHtml(cutLabel)}</a></div>` : ''}
    </div>
  `;
}

let songRenderToken = 0; // 分批渲染令牌：新一轮渲染使进行中的批次失效

function renderSongs(errorMessage = '') {
  if (state.currentRoom.placeholder) {
    dom.songListWrap.innerHTML = `
      <div class="card empty-card">
        <div class="empty-title">小松绿歌单暂时还是空的</div>
        <div>嗯，现在还没有小松绿专属歌单网站，所以这里只先保留独立房间的数据位。等以后有源站了，再直接接进来就可以啦。</div>
      </div>
    `;
    dom.songMetaText.textContent = '当前房间还没有可读取的歌曲数据。';
    deselectSong(true);
    return;
  }

  if (errorMessage) {
    dom.songListWrap.innerHTML = `
      <div class="card empty-card">
        <div class="empty-title">歌曲加载失败</div>
        <div>${escHtml(errorMessage)}</div>
      </div>
    `;
    deselectSong(true);
    return;
  }

  if (state.isSongLoading && state.allSongs.length === 0) {
    dom.songListWrap.innerHTML = `
      <div class="card empty-card">
        <div class="empty-title">正在加载歌单…</div>
        <div>等一下哦，我在把远端歌单搬过来。</div>
      </div>
    `;
    return;
  }

  if (state.filteredSongs.length === 0) {
    dom.songListWrap.innerHTML = `
      <div class="card empty-card">
        <div class="empty-title">没有找到匹配歌曲</div>
        <div>可以试试换个关键词，或者把高级筛选清掉一点。</div>
      </div>
    `;
    deselectSong(true);
    return;
  }

  // 分批渲染：每帧插入 80 行，避免上千行一次性渲染阻塞主线程
  const list = state.filteredSongs;
  const token = ++songRenderToken;
  const CHUNK = 80;
  let i = 0;
  let html = '';
  dom.songListWrap.innerHTML = '';
  function step() {
    if (token !== songRenderToken) return; // 新一轮渲染已开始，放弃本批
    const end = Math.min(i + CHUNK, list.length);
    for (; i < end; i++) html += getSongCardHtml(list[i]);
    dom.songListWrap.insertAdjacentHTML('beforeend', html);
    html = '';
    if (i < list.length) requestAnimationFrame(step);
  }
  step();
}

function syncFilterSummary() {
  const activeParts = [];
  if (state.songFilters.languages.length) activeParts.push(`语言 ${state.songFilters.languages.join(' / ')}`);
  if (state.songFilters.tags.length) activeParts.push(`标签 ${state.songFilters.tags.join(' / ')}`);
  if (state.songFilters.countMin !== null || state.songFilters.countMax !== null) {
    activeParts.push(`次数 ${state.songFilters.countMin ?? '不限'}-${state.songFilters.countMax ?? '不限'}`);
  }
  if (state.songFilters.daysMin !== null || state.songFilters.daysMax !== null) {
    activeParts.push(`天数 ${state.songFilters.daysMin ?? '不限'}-${state.songFilters.daysMax ?? '不限'}`);
  }
  dom.toggleFilterBtn.classList.toggle('active', state.filtersVisible || activeParts.length > 0);
  dom.favoritesOnlyBtn.classList.toggle('active', state.favoritesOnly);
  dom.favoritesOnlyBtn.textContent = state.favoritesOnly ? '只看中意（开）' : '仅看中意';
}

function selectSong(song) {
  state.selectedSong = song;
  dom.actionPanel.style.display = 'block';
  dom.selectedSongName.textContent = `🎵 ${song.display_song_name || song.song_name || ''}`;
  const blocked = isLockedSong(song) || isBannedSong(song);
  dom.orderBtn.disabled = blocked;
  updatePlayUI();
  renderSongs();
}

function deselectSong(silent = false) {
  state.selectedSong = null;
  dom.actionPanel.style.display = 'none';
  if (!silent) renderSongs();
}

async function sendToChatInput(text) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action: 'typeInChat', text }, async response => {
      if (chrome.runtime.lastError || !response || !response.success) {
        await copyToClipboard(text);
        showToast(`已复制到剪贴板：${text}`);
        resolve(false);
        return;
      }
      resolve(true);
    });
  });
}

// 点歌文案：固定格式「点歌 歌名」（有版本带版本，无版本带歌手）
function buildOrderText(song) {
  const name = (song && (song.display_song_name || song.song_name) || '').trim();
  if (!name) return '';
  let version = (song.display_version || '').trim();
  if (version === 'ゆめこ') version = 'yumeko';
  const artist = (song.artist || '').trim();
  const parts = [name];
  if (version) parts.push(version);
  else if (artist) parts.push(artist);
  return `点歌 ${parts.join(' ')}`;
}

async function doOrder() {
  if (!state.selectedSong) return;
  const text = buildOrderText(state.selectedSong);
  if (!text) return;
  const ok = await sendToChatInput(text);
  if (ok !== false) showToast(`已填入：${text}`);
}

function renderLanguageChips() {
  const langs = Array.from(new Set(state.allSongs.map(song => song.language || '').filter(Boolean))).sort((a, b) => a.localeCompare(b, 'zh-CN'));
  if (langs.length === 0) {
    dom.languageChips.innerHTML = '<span class="muted">暂无语言标签</span>';
    return;
  }
  dom.languageChips.innerHTML = langs.map(lang => {
    const active = state.songFilters.languages.includes(lang);
    return `<button class="filter-chip${active ? ' active' : ''}" data-lang-chip="${escHtml(lang)}">${escHtml(lang)}</button>`;
  }).join('');
}

// 标签筛选：取全部歌曲 type 标签中出现次数最高的前 N 个
const TAG_FILTER_LIMIT = 10;

function getTopTags(limit = TAG_FILTER_LIMIT) {
  const count = new Map();
  state.allSongs.forEach(song => {
    String(song.type || '').split(/[、,，/／|｜\s]+/).map(t => t.trim()).filter(Boolean).forEach(tag => {
      count.set(tag, (count.get(tag) || 0) + 1);
    });
  });
  return Array.from(count.entries())
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], 'zh-CN'))
    .slice(0, limit)
    .map(([tag]) => tag);
}

function renderTagChips() {
  const topTags = getTopTags();
  if (topTags.length === 0) {
    dom.tagChips.innerHTML = '<span class="muted">暂无标签</span>';
    return;
  }
  dom.tagChips.innerHTML = topTags.map(tag => {
    const active = state.songFilters.tags.includes(tag);
    return `<button class="filter-chip${active ? ' active' : ''}" data-tag-chip="${escHtml(tag)}">${escHtml(tag)}</button>`;
  }).join('');
}

function favoriteSnapshotFromSong(song, overrides = {}) {
  return {
    key: getFavoriteKey(song),
    song_id: song.song_id,
    row_key: song.row_key || song.song_name || '',
    song_name: song.song_name || '',
    display_song_name: song.display_song_name || song.song_name || '',
    artist: song.artist || '',
    artist_search: song.artist_search || '',
    feat_artist: song.feat_artist || '',
    sing_count: song.sing_count || 0,
    last_sing_at: song.last_sing_at || '',
    status_labels: song.status_labels || '',
    language: song.language || '',
    display_version: song.display_version || '',
    tone: song.tone ?? '',
    remark: song.remark || '',
    type: song.type || '',
    identification: song.identification || '',
    importedManual: false,
    ...overrides
  };
}

function normalizeFavoriteMap(raw) {
  if (!raw || typeof raw !== 'object') return {};
  const out = {};
  Object.keys(raw).forEach(key => {
    const item = raw[key];
    if (!item || typeof item !== 'object') return;
    out[key] = {
      key,
      song_id: item.song_id ?? null,
      row_key: item.row_key || item.song_name || '',
      song_name: item.song_name || item.display_song_name || '',
      display_song_name: item.display_song_name || item.song_name || '',
      artist: item.artist || '',
      artist_search: item.artist_search || '',
      feat_artist: item.feat_artist || '',
      sing_count: Number(item.sing_count || 0),
      last_sing_at: item.last_sing_at || '',
      status_labels: item.status_labels || '',
      language: item.language || '',
      display_version: item.display_version || '',
      tone: item.tone ?? '',
      remark: item.remark || '',
      type: item.type || '',
      identification: item.identification || '',
      importedManual: !!item.importedManual
    };
  });
  return out;
}

function hydrateFavoriteList() {
  const songsByKey = new Map(state.allSongs.map(song => [getFavoriteKey(song), song]));
  state.favoriteList = Object.values(state.favoritesMap).map(snapshot => {
    const liveSong = snapshot.key ? songsByKey.get(snapshot.key) : null;
    if (liveSong) {
      return favoriteSnapshotFromSong(liveSong, { key: snapshot.key, importedManual: !!snapshot.importedManual });
    }
    return { ...snapshot };
  }).filter(item => item && item.key);
}

async function loadFavorites() {
  const result = await storageGet([FAVORITES_KEY, 'favorites:miting', 'favorites:xiaosonglu']);
  state.favoritesMap = normalizeFavoriteMap(result[FAVORITES_KEY]);

  // 迁移旧版「按房间分存」的收藏 → 全局共享存档（改为歌名键）
  let migrated = 0;
  ['miting', 'xiaosonglu'].forEach(roomKey => {
    const legacy = result[`favorites:${roomKey}`];
    if (!legacy || typeof legacy !== 'object') return;
    Object.values(normalizeFavoriteMap(legacy)).forEach(item => {
      const name = String(item.display_song_name || item.song_name || '').trim();
      if (!name) return;
      const key = `name:${name}`;
      if (!state.favoritesMap[key]) {
        state.favoritesMap[key] = { ...item, key };
        migrated += 1;
      }
    });
  });
  if (migrated) {
    await saveFavorites();
    chrome.storage.local.remove(['favorites:miting', 'favorites:xiaosonglu']);
  }

  hydrateFavoriteList();
  renderFavorites();

  // 加载歌单时，从网页（viridis.love）同步同一份中意数据
  await syncFavoritesFromWeb();
}

async function saveFavorites() {
  await storageSet({ [FAVORITES_KEY]: state.favoritesMap });
  pushFavoritesToWeb();
}

// 从网页（viridis.love）同步中意：网页数据为权威，合并插件本地手动导入条目
async function syncFavoritesFromWeb() {
  try {
    // 优先实时查询 viridis.love 页面（内容脚本直接读 localStorage，最准）
    let resp = await new Promise(resolve => {
      chrome.tabs.query({ url: 'https://viridis.love/*' }, tabs => {
        const tab = tabs && tabs.find(t => t.id != null);
        if (!tab) return resolve(null);
        try {
          chrome.tabs.sendMessage(tab.id, { type: 'GET_WEB_FAVORITES_PAGE' }, result => {
            if (chrome.runtime.lastError) return resolve(null);
            resolve(result || null);
          });
        } catch (e) {
          resolve(null);
        }
      });
    });

    // 页面查询失败 → 回退 background 缓存（网页推送过的最新数据）
    if (!resp || !resp.data) {
      resp = await new Promise(resolve => {
        chrome.runtime.sendMessage({ type: 'GET_WEB_FAVORITES' }, resolve);
      });
    }

    if (!resp || !resp.data || typeof resp.data !== 'object') return false;
    const webMap = normalizeFavoriteMap(resp.data);
    // 保留插件本地独有的手动导入条目（网页可能还没同步到）
    const merged = { ...webMap };
    Object.entries(state.favoritesMap).forEach(([key, item]) => {
      if (!merged[key] && item && item.importedManual) merged[key] = item;
    });
    state.favoritesMap = merged;
    await storageSet({ [FAVORITES_KEY]: state.favoritesMap });
    hydrateFavoriteList();
    renderFavorites();
    return true;
  } catch (e) {
    console.warn('[歌单助手] 从网页同步中意失败:', e);
    return false;
  }
}

// 插件中意推回网页（需要 viridis.love 标签页开着才会真正写回）
function pushFavoritesToWeb() {
  try {
    chrome.runtime.sendMessage({ type: 'PLUGIN_FAVORITES_SYNC', data: state.favoritesMap });
  } catch (e) { /* 页面未就绪时静默忽略 */ }
}

async function toggleFavoriteBySong(song) {
  const key = getFavoriteKey(song);
  if (!key || !canFavoriteSong(song)) return;
  if (state.favoritesMap[key]) delete state.favoritesMap[key];
  else state.favoritesMap[key] = favoriteSnapshotFromSong(song);
  await saveFavorites();
  hydrateFavoriteList();
  applySongFilters();
}

function getFavoriteArtistLine(song) {
  return [song.artist || '', song.feat_artist ? `feat. ${song.feat_artist}` : ''].filter(Boolean).join(' · ');
}

function getFavoriteImportKey(name, artist = '') {
  // 与全局存档一致用歌名键，跨直播间可互相匹配
  return `name:${String(name || '').trim()}`;
}

function findSongForImportedLine(name, artist = '') {
  const targetName = String(name || '').trim().toLowerCase();
  const targetArtist = String(artist || '').trim().toLowerCase();
  if (!targetName) return null;
  const exact = state.allSongs.find(song => {
    const names = [song.display_song_name, song.song_name, song.row_key, song.search_name]
      .map(item => String(item || '').trim().toLowerCase())
      .filter(Boolean);
    if (!names.includes(targetName)) return false;
    if (!targetArtist) return true;
    const artists = [song.artist, song.artist_search, song.feat_artist]
      .map(item => String(item || '').trim().toLowerCase())
      .filter(Boolean);
    return artists.some(item => item.includes(targetArtist));
  });
  if (exact) return exact;
  return state.allSongs.find(song => {
    const names = [song.display_song_name, song.song_name, song.row_key, song.search_name]
      .map(item => String(item || '').trim().toLowerCase())
      .filter(Boolean);
    return names.some(item => item.includes(targetName) || targetName.includes(item));
  }) || null;
}

function setFavoritesImportVisible(visible) {
  state.favoritesImportVisible = !!visible;
  dom.favoritesImportCard.classList.toggle('show', state.favoritesImportVisible);
  dom.favoritesToggleImportBtn.classList.toggle('active', state.favoritesImportVisible);
  dom.favoritesToggleImportBtn.textContent = state.favoritesImportVisible ? '收起导入' : '导入清单';
}

function renderFavorites() {
  hydrateFavoriteList();
  // 全局共享存档 + 按当前房间静默过滤：只显示本房间歌单里存在的歌（主播唱过的）
  const roomKeys = new Set(state.allSongs.map(song => getFavoriteKey(song)));
  const list = state.favoriteList
    .filter(item => item.key && roomKeys.has(item.key))
    .sort((a, b) => compareSongs(a, b, 'last_sing_at', 'desc'));
  dom.favoritesCountText.textContent = `${list.length} 首`;
  dom.favoritesMetaText.textContent = list.length
    ? `${state.currentRoom.name} · 本房间 ${list.length} 首`
    : `${state.currentRoom.name} · 本房间还没有中意歌曲。`;

  if (!list.length) {
    dom.favoritesListWrap.innerHTML = '<div class="fav-empty">本房间还没有中意歌曲。可以在总览点星星收藏，或导入一份存档（其他直播间收藏的歌会自动出现）。</div>';
    return;
  }

  dom.favoritesListWrap.innerHTML = list.map(song => {
    const artistLine = getFavoriteArtistLine(song) || '未填写歌手';
    const lastText = song.last_sing_at ? `最近 ${formatLastSing(song.last_sing_at)}` : '还没有最近演唱数据';
    const statuses = getVisibleStatusLabels(song.status_labels);
    const days = getDaysAgo(song.last_sing_at);
    const extraBadges = [];
    if (song.language) extraBadges.push(`<span class="badge ${getLanguageBadgeClass(song.language)}">${escHtml(song.language)}</span>`);
    if (song.display_version) extraBadges.push(`<span class="badge">Ver. ${escHtml(song.display_version)}</span>`);
    getVisibleTypeLabels(song.type).forEach(type => extraBadges.push(`<span class="badge">${escHtml(type)}</span>`));
    if (song.importedManual) extraBadges.push('<span class="badge">导入</span>');
    return `
      <div class="fav-item" data-favorite-key-item="${escHtml(song.key)}">
        <div class="fav-item-main">
          <div class="fav-item-name">${escHtml(song.display_song_name || song.song_name || '')}</div>
          <div class="fav-item-meta">${escHtml(artistLine)}<br>${escHtml(lastText)}</div>
          <div class="fav-item-extra">
            ${extraBadges.join('')}
            <span class="badge count">次数 ${escHtml(song.sing_count || 0)}</span>
            ${song.tone !== '' && song.tone !== null && song.tone !== undefined ? `<span class="badge tone">Tone ${escHtml(formatTone(song.tone))}</span>` : ''}
            ${days === null ? '' : `<span class="fav-item-days">${days} 天</span>`}
          </div>
          ${statuses.length ? `<div class="fav-item-status" style="margin-top:8px;">${statuses.map(item => `<span class="badge status">${escHtml(item)}</span>`).join('')}</div>` : ''}
          <div class="fav-item-actions">
            <button class="tool-btn" data-favorite-order-key="${escHtml(song.key)}">点这首</button>
            ${song.song_name || song.display_song_name ? `<button class="tool-btn" data-favorite-copy-key="${escHtml(song.key)}">复制歌名</button>` : ''}
          </div>
        </div>
        <button class="fav-item-remove" data-favorite-remove-key="${escHtml(song.key)}" title="移除">✕</button>
      </div>
    `;
  }).join('');
}

async function exportFavorites() {
  if (!state.favoriteList.length) {
    showToast('中意清单还是空的');
    return;
  }
  const lines = ['歌名\t歌手\t次数\t最近演唱\t状态'];
  state.favoriteList.forEach(song => {
    lines.push([
      song.display_song_name || song.song_name || '',
      song.artist || '',
      song.sing_count || 0,
      song.last_sing_at || '',
      getVisibleStatusText(song.status_labels)
    ].join('\t'));
  });
  await copyToClipboard(lines.join('\n'));
  showToast('已复制中意清单（TSV）');
}

async function importFavoritesFromText(rawText) {
  const raw = rawText !== undefined ? String(rawText || '') : String(dom.favoritesImportInput.value || '');
  const lines = raw.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  if (!lines.length) {
    showToast('先贴一份清单内容嘛');
    return;
  }

  let matched = 0;
  let manual = 0;
  let ignored = 0;

  lines.forEach(line => {
    // 注意：不能 filter(Boolean) 删空列——歌手为空时列会错位（次数被误当作歌手）
    const parts = line.split('\t').map(item => item.trim());
    const first = parts[0] || '';
    if (!first || first === '歌名' || /^song\s*name$/i.test(first)) {
      ignored += 1;
      return;
    }
    const artist = parts[1] || '';
    const found = findSongForImportedLine(first, artist);
    if (found) {
      state.favoritesMap[getFavoriteKey(found)] = favoriteSnapshotFromSong(found);
      matched += 1;
      return;
    }
    const key = getFavoriteImportKey(first, artist);
    state.favoritesMap[key] = {
      key,
      song_id: null,
      row_key: first,
      song_name: first,
      display_song_name: first,
      artist,
      artist_search: '',
      feat_artist: '',
      sing_count: 0,
      last_sing_at: '',
      status_labels: '',
      language: '',
      display_version: '',
      tone: '',
      remark: '',
      type: '',
      identification: '',
      importedManual: true
    };
    manual += 1;
  });

  await saveFavorites();
  hydrateFavoriteList();
  applySongFilters();
  setFavoritesImportVisible(false);
  dom.favoritesImportInput.value = '';
  showToast(`导入完成：匹配 ${matched} 首，手动保留 ${manual} 首${ignored ? `，忽略 ${ignored} 行` : ''}`);
}

async function clearFavorites() {
  if (!state.favoriteList.length) {
    showToast('中意清单已经是空的啦');
    return;
  }
  if (!window.confirm(`确定清空 ${state.favoriteList.length} 首中意歌曲吗？`)) return;
  state.favoritesMap = {};
  await saveFavorites();
  hydrateFavoriteList();
  applySongFilters();
  showToast('已清空中意清单');
}

// ---- 中意存档 文件导入/导出（与歌单网站导出格式一致：歌名\t歌手\t次数\t最近演唱日期） ----

function getArchiveExportFileName() {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  return `${state.currentRoom.name}歌单 ${String(d.getFullYear()).slice(-2)}.${pad(d.getMonth() + 1)}.${pad(d.getDate())}.txt`;
}

async function exportFavoritesToFile() {
  if (!state.favoriteList.length) {
    showToast('中意清单还是空的');
    return;
  }
  const lines = ['歌名\t歌手\t次数\t最近演唱日期'];
  state.favoriteList.forEach(song => {
    let artist = song.artist || '';
    if (song.feat_artist) artist = artist ? `${artist} feat. ${song.feat_artist}` : `feat. ${song.feat_artist}`;
    lines.push([
      song.display_song_name || song.song_name || '',
      artist,
      song.sing_count || 0,
      song.last_sing_at || ''
    ].join('\t'));
  });
  const text = '\uFEFF' + lines.join('\r\n'); // BOM 便于 Excel 打开
  const fileName = getArchiveExportFileName();

  // 悬浮面板的 iframe 与 B 站页面跨域，Chrome 会拦截 iframe 内下载 → 退回剪贴板
  const embedded = new URLSearchParams(location.search).get('embedded') === '1';
  if (embedded) {
    await copyToClipboard(text);
    showToast(`已复制存档内容到剪贴板（悬浮面板内无法直接下载，请粘贴保存为「${fileName}」）`);
    return;
  }

  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast(`已导出存档：${fileName}`);
}

function handleFavoriteFileImport() {
  const file = dom.favoritesImportFileInput.files && dom.favoritesImportFileInput.files[0];
  dom.favoritesImportFileInput.value = ''; // 允许重复选择同一文件
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    importFavoritesFromText(String(reader.result || '')).then(() => {
      showToast(`已从「${file.name}」导入中意清单`);
    });
  };
  reader.onerror = () => showToast('读取存档文件失败');
  reader.readAsText(file, 'utf-8');
}

// 语言 全选/全不选 = 不过滤（全选只是视觉上全勾选）
function setLanguageChipsAll(all) {
  state.songFilters.languages = [];
  renderLanguageChips();
  dom.languageChips.querySelectorAll('[data-lang-chip]').forEach(el => {
    el.classList.toggle('active', all);
  });
  applySongFilters();
}

// 预设按钮高亮：与当前次数/天数输入一致
function syncPresetButtons() {
  dom.countPresetRow.querySelectorAll('.preset-btn').forEach(btn => {
    const min = btn.dataset.countMin === '' ? null : Number(btn.dataset.countMin);
    const max = btn.dataset.countMax === '' ? null : Number(btn.dataset.countMax);
    btn.classList.toggle('active', min === state.songFilters.countMin && max === state.songFilters.countMax);
  });
  dom.daysPresetRow.querySelectorAll('.preset-btn').forEach(btn => {
    const min = btn.dataset.daysMin === '' ? null : Number(btn.dataset.daysMin);
    const max = btn.dataset.daysMax === '' ? null : Number(btn.dataset.daysMax);
    btn.classList.toggle('active', min === state.songFilters.daysMin && max === state.songFilters.daysMax);
  });
}

async function loadCallwords() {
  const keys = getStorageKeys(state.currentRoomKey);
  const result = await storageGet([keys.callwords]);
  state.callwords = Array.isArray(result[keys.callwords]) ? result[keys.callwords] : [];
  renderCallwords();
}

async function saveCallwords() {
  const keys = getStorageKeys(state.currentRoomKey);
  await storageSet({ [keys.callwords]: state.callwords });
}

function renderCallwords() {
  if (!state.callwords.length) {
    dom.callwordListWrap.innerHTML = '<div class="callword-empty">这个房间还没有存打 call 词呢，可以先加一条常用弹幕。</div>';
    return;
  }
  dom.callwordListWrap.innerHTML = state.callwords.map((word, index) => `
    <div class="callword-item">
      <div class="callword-text">${escHtml(word)}</div>
      <button class="callword-btn" data-callword-use="${index}">使用</button>
      <button class="callword-btn danger" data-callword-del="${index}">删除</button>
    </div>
  `).join('');
}

async function addCallword() {
  const word = (dom.callwordInput.value || '').trim();
  if (!word) {
    showToast('先输入一条弹幕词嘛');
    return;
  }
  if (state.callwords.includes(word)) {
    showToast('这条已经存过了');
    return;
  }
  state.callwords.push(word);
  dom.callwordInput.value = '';
  await saveCallwords();
  renderCallwords();
  showToast('已保存打 call 词');
}

async function useCallword(index) {
  const word = state.callwords[index];
  if (!word) return;
  const ok = await sendToChatInput(word);
  if (ok !== false) showToast(`已填入：${word}`);
}

async function deleteCallword(index) {
  state.callwords.splice(index, 1);
  await saveCallwords();
  renderCallwords();
  showToast('已删除');
}

async function fetchHistoryMeta(room, forceRefresh = false) {
  if (room.placeholder || !room.supportsHistory || (!room.historyPageUrl && !room.historyDataUrl)) {
    state.historyMeta = { dateTree: {}, latest: null };
    return state.historyMeta;
  }

  const keys = getStorageKeys(state.currentRoomKey);
  if (!forceRefresh) {
    const cached = await storageGet([keys.historyCache, keys.historyCacheTime]);
    if (cached[keys.historyCache] && cached[keys.historyCacheTime] && Date.now() - cached[keys.historyCacheTime] < HISTORY_CACHE_TTL) {
      state.historyMeta = cached[keys.historyCache];
      return state.historyMeta;
    }
  }

  let meta;
  if (isJsonRoom(room) && room.historyDataUrl) {
    meta = await fetchLocalJson(room.historyDataUrl, room.historyDataFallback);
    meta.latest = meta.latest || findLatestDateFromTree(meta.dateTree || {});
  } else {
    const resp = await fetch(room.historyPageUrl, { cache: 'no-cache' });
    if (!resp.ok) throw new Error(`历史页访问失败（HTTP ${resp.status}）`);
    const html = await resp.text();
    const dateTreeMatch = html.match(/var\s+dateTree\s*=\s*(\{[\s\S]*?\});/);
    if (!dateTreeMatch) throw new Error('没有找到历史日期树');
    const dateTree = JSON.parse(dateTreeMatch[1]);
    meta = { dateTree, latest: findLatestDateFromTree(dateTree) };
  }

  await storageSet({
    [keys.historyCache]: meta,
    [keys.historyCacheTime]: Date.now()
  });
  state.historyMeta = meta;
  return meta;
}

function findLatestDateFromTree(dateTree) {
  const years = Object.keys(dateTree || {}).sort((a, b) => Number(b) - Number(a));
  for (const year of years) {
    const months = Object.keys(dateTree[year] || {}).sort((a, b) => Number(b) - Number(a));
    for (const month of months) {
      const days = Object.keys(dateTree[year][month] || {}).sort((a, b) => Number(b) - Number(a));
      if (days.length) return { year, month, day: days[0] };
    }
  }
  return null;
}

function fillHistoryDateSelectors() {
  const meta = state.historyMeta;
  const dateTree = (meta && meta.dateTree) || {};
  const years = Object.keys(dateTree).sort((a, b) => Number(b) - Number(a));
  dom.historyYearSelect.innerHTML = years.map(year => `<option value="${year}">${year} 年</option>`).join('');

  if (!years.length) {
    dom.historyMonthSelect.innerHTML = '';
    dom.historyDaySelect.innerHTML = '';
    return;
  }

  const current = state.historySelectedDate || meta.latest || { year: years[0] };
  dom.historyYearSelect.value = current.year;
  fillHistoryMonthSelector();
  dom.historyMonthSelect.value = current.month;
  fillHistoryDaySelector();
  dom.historyDaySelect.value = current.day;
}

function fillHistoryMonthSelector() {
  const year = dom.historyYearSelect.value;
  const dateTree = (state.historyMeta && state.historyMeta.dateTree) || {};
  const months = Object.keys((dateTree[year] || {})).sort((a, b) => Number(b) - Number(a));
  dom.historyMonthSelect.innerHTML = months.map(month => `<option value="${month}">${month} 月</option>`).join('');
}

function fillHistoryDaySelector() {
  const year = dom.historyYearSelect.value;
  const month = dom.historyMonthSelect.value;
  const dateTree = (state.historyMeta && state.historyMeta.dateTree) || {};
  const days = Object.keys((((dateTree[year] || {})[month]) || {})).sort((a, b) => Number(b) - Number(a));
  dom.historyDaySelect.innerHTML = days.map(day => `<option value="${day}">${day} 日</option>`).join('');
}

async function loadHistory(forceRefreshMeta = false) {
  const room = state.currentRoom;
  if (room.placeholder || !room.supportsHistory) {
    dom.historyMetaText.textContent = '当前房间暂无历史数据源。';
    dom.historyListWrap.innerHTML = `
      <div class="card empty-card">
        <div class="empty-title">历史页面暂时不可用</div>
        <div>小松绿这边还没有接入独立历史歌单，所以这里只先留空。</div>
      </div>
    `;
    return;
  }

  try {
    const meta = await fetchHistoryMeta(room, forceRefreshMeta);
    if (!meta || !meta.latest) {
      dom.historyMetaText.textContent = '没有可用的历史日期。';
      dom.historyListWrap.innerHTML = `
        <div class="card empty-card">
          <div class="empty-title">还没有历史数据</div>
          <div>这个房间暂时没有读到历史每日歌曲记录。</div>
        </div>
      `;
      return;
    }

    if (!state.historySelectedDate) state.historySelectedDate = meta.latest;
    fillHistoryDateSelectors();
    await loadHistoryPage(1);
  } catch (error) {
    console.error('[歌单助手] 加载历史元数据失败:', error);
    dom.historyMetaText.textContent = `历史数据加载失败：${error.message}`;
    dom.historyListWrap.innerHTML = `
      <div class="card empty-card">
        <div class="empty-title">历史数据加载失败</div>
        <div>${escHtml(error.message)}</div>
      </div>
    `;
  }
}

async function loadHistoryPage(page = 1) {
  const room = state.currentRoom;
  if (room.placeholder || (!room.historyPageUrl && !room.historyDataUrl)) return;
  const year = dom.historyYearSelect.value;
  const month = dom.historyMonthSelect.value;
  const day = dom.historyDaySelect.value;
  if (!year || !month || !day) return;

  state.isHistoryLoading = true;
  state.historySelectedDate = { year, month, day };
  dom.historyMetaText.textContent = `正在读取 ${year}-${month}-${day} 的历史记录…`;
  dom.historyListWrap.innerHTML = `
    <div class="card empty-card">
      <div class="empty-title">历史加载中…</div>
      <div>等一下，我在翻歌单档案。</div>
    </div>
  `;

  try {
    let parsed;
    if (isJsonRoom(room) && room.historyDataUrl) {
      const payload = state.historyMeta && state.historyMeta.byDate ? state.historyMeta : await fetchLocalJson(room.historyDataUrl, room.historyDataFallback);
      const dateKey = `${year}-${month}-${day}`;
      const entries = Array.isArray(payload.byDate && payload.byDate[dateKey]) ? payload.byDate[dateKey].map(mapLocalHistoryEntry) : [];
      parsed = paginateLocalHistory(entries, page, room.historyPageSize || 30);
    } else {
      const url = new URL(room.historyPageUrl);
      url.searchParams.set('year', year);
      url.searchParams.set('month', month);
      url.searchParams.set('day', day);
      url.searchParams.set('page', String(page));
      const resp = await fetch(url.toString(), { cache: 'no-cache' });
      if (!resp.ok) throw new Error(`历史页面访问失败（HTTP ${resp.status}）`);
      const html = await resp.text();
      parsed = parseHistoryPageHtml(html);
    }

    state.historyEntries = parsed.entries;
    state.historyPage = parsed.page;
    state.historyTotalPages = parsed.totalPages;
    renderHistoryEntries();
    const totalCount = isJsonRoom(room) && state.historyMeta && state.historyMeta.byDate
      ? ((state.historyMeta.byDate[`${year}-${month}-${day}`] || []).length)
      : parsed.entries.length;
    dom.historyMetaText.textContent = `${year}-${month}-${day} · 第 ${state.historyPage} / ${state.historyTotalPages} 页 · 共 ${totalCount} 条`;
    syncHistoryPager();
  } catch (error) {
    console.error('[歌单助手] 加载历史列表失败:', error);
    dom.historyMetaText.textContent = `历史记录加载失败：${error.message}`;
    dom.historyListWrap.innerHTML = `
      <div class="card empty-card">
        <div class="empty-title">历史记录加载失败</div>
        <div>${escHtml(error.message)}</div>
      </div>
    `;
  } finally {
    state.isHistoryLoading = false;
  }
}

function parseHistoryPageHtml(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const rows = Array.from(doc.querySelectorAll('table tbody tr'));
  const entries = rows.map(row => {
    const cells = row.querySelectorAll('td');
    const name = cells[0] ? cells[0].textContent.replace(/\s+/g, ' ').trim() : '';
    const singTime = cells[1] ? cells[1].textContent.replace(/\s+/g, ' ').trim() : '';
    const statusText = cells[2] ? cells[2].textContent.replace(/\s+/g, ' ').trim() : '';
    return {
      song_name: name,
      sing_time: singTime,
      statuses: getVisibleStatusLabels(statusText)
    };
  }).filter(item => item.song_name);

  let currentPage = 1;
  let totalPages = 1;
  const currentEl = doc.querySelector('.pagination .current');
  if (currentEl) currentPage = Number(currentEl.textContent.trim()) || 1;
  const pageNumbers = Array.from(doc.querySelectorAll('.pagination a, .pagination .current'))
    .map(el => Number((el.textContent || '').trim()))
    .filter(num => Number.isFinite(num));
  if (pageNumbers.length) totalPages = Math.max(...pageNumbers);

  return { entries, page: currentPage, totalPages };
}

function renderHistoryEntries() {
  if (!state.historyEntries.length) {
    dom.historyListWrap.innerHTML = `
      <div class="card empty-card">
        <div class="empty-title">这一天没有记录</div>
        <div>可以换个日期看看，也许那天刚好没有唱歌。</div>
      </div>
    `;
    return;
  }

  dom.historyListWrap.innerHTML = state.historyEntries.map((entry, index) => {
    return `
    <div class="history-item" data-history-index="${index}">
      <div class="history-top">
        <div class="history-main">
          <div class="history-name">${escHtml(entry.song_name)}</div>
          <div class="history-sub">演唱时间：${escHtml(entry.sing_time || '未记录')}${entry.artist ? ` · ${escHtml(entry.artist)}` : ''}</div>
        </div>
        <button class="tool-btn" data-history-order="${index}">点这首</button>
      </div>
      ${entry.replay_title || entry.replay_url ? `<div class="history-sub" style="margin-top:8px;">回放：${entry.replay_url ? `<a href="${escHtml(entry.replay_url)}" target="_blank" rel="noreferrer">${escHtml(entry.replay_title || '打开回放')}</a>` : escHtml(entry.replay_title)}</div>` : ''}
    </div>
  `;
  }).join('');
}

function syncHistoryPager() {
  dom.historyPageInfo.textContent = `第 ${state.historyPage} / ${state.historyTotalPages} 页`;
  dom.historyPrevBtn.disabled = state.historyPage <= 1;
  dom.historyNextBtn.disabled = state.historyPage >= state.historyTotalPages;
}

async function loadSongDetail(songName, displayLabel, singCount) {
  if (!songName) return;
  dom.detailTitle.textContent = displayLabel || songName;
  dom.detailSub.textContent = singCount != null ? `总演唱 ${singCount} 次` : '正在加载详情…';
  dom.detailBody.innerHTML = '<div class="muted">正在加载演唱详情…</div>';
  dom.detailOverlay.classList.add('show');
  dom.detailModal.classList.add('show');

  const cacheKey = `${state.currentRoomKey}:${songName}`;
  if (state.detailsCache[cacheKey]) {
    renderSongDetail(state.detailsCache[cacheKey]);
    return;
  }

  try {
    let parsed;
    if (isJsonRoom(state.currentRoom) && state.currentRoom.detailDataUrl) {
      const detailsPayload = state.detailsCache[`__details_file__:${state.currentRoomKey}`] || await fetchLocalJson(state.currentRoom.detailDataUrl, state.currentRoom.detailDataFallback);
      state.detailsCache[`__details_file__:${state.currentRoomKey}`] = detailsPayload;
      const bySongKey = detailsPayload.bySongKey || {};
      const match = Object.values(bySongKey).find(item => {
        return item && [item.row_key, item.song_name, item.display_song_name].filter(Boolean).includes(songName);
      });
      parsed = match ? {
        display_song_name: match.display_song_name || match.song_name || songName,
        total_count: match.total_count,
        cut_link: getSongCutUrl(match.cut_link),
        entries: Array.isArray(match.entries) ? match.entries.map(entry => ({
          ...entry,
          cut_link: getSongCutUrl(entry.cut_link)
        })) : []
      } : { display_song_name: displayLabel || songName, total_count: singCount || 0, cut_link: '', entries: [] };
    } else {
      if (state.currentRoom.placeholder || !state.currentRoom.supportsRemoteDetails) {
        dom.detailBody.innerHTML = '<div class="muted">当前房间还没有可用的演唱详情接口。</div>';
        return;
      }
      const url = new URL(state.currentRoom.detailApiBase);
      url.searchParams.set('action', 'get_song_details');
      url.searchParams.set('song_name', songName);
      url.searchParams.set('_t', String(Date.now()));
      const resp = await fetch(url.toString(), { headers: { Accept: 'application/json' } });
      if (!resp.ok) throw new Error(`接口请求失败（HTTP ${resp.status}）`);
      const data = await resp.json();
      if (!data || !data.success) throw new Error((data && data.msg) || '详情返回失败');
      parsed = parseSongDetailResponse(data);
    }
    state.detailsCache[cacheKey] = parsed;
    renderSongDetail(parsed);
  } catch (error) {
    console.error('[歌单助手] 详情加载失败:', error);
    dom.detailBody.innerHTML = `<div class="muted">加载失败：${escHtml(error.message)}</div>`;
  }
}

function parseSongDetailResponse(data) {
  const doc = new DOMParser().parseFromString(data.html || '', 'text/html');
  const entries = Array.from(doc.querySelectorAll('tbody tr')).map(row => {
    const cells = row.querySelectorAll('td');
    return {
      date: cells[0] ? cells[0].textContent.trim() : '',
      time: cells[1] ? cells[1].textContent.trim() : '',
      status: cells[2] ? cells[2].textContent.replace(/\s+/g, ' ').trim() : ''
    };
  }).filter(item => item.date);
  return {
    display_song_name: data.display_song_name || '',
    total_count: data.total_count,
    entries
  };
}

function renderSongDetail(detail) {
  if (detail.display_song_name) dom.detailTitle.textContent = detail.display_song_name;
  if (detail.total_count != null) dom.detailSub.textContent = `总演唱 ${detail.total_count} 次`;
  const primaryCutUrl = getSongCutUrl(detail.cut_link);
  if (!detail.entries.length) {
    dom.detailBody.innerHTML = '<div class="muted">没有找到对应的演唱记录。</div>';
    return;
  }
  const rows = detail.entries.map(item => {
    const visibleStatus = getVisibleStatusText(item.status) || '—';
    return `
    <tr>
      <td>${escHtml(item.date || '—')}</td>
      <td>${escHtml(item.time || '—')}</td>
      <td>${escHtml(visibleStatus)}</td>
    </tr>
  `;
  }).join('');
  const replayExtra = detail.entries.some(item => item.replay_title || item.replay_url)
    ? `<div style="margin-top:10px; font-size:12px; color:#6271a8; line-height:1.7;">${detail.entries.map(item => {
        if (!item.replay_title && !item.replay_url) return '';
        const label = escHtml(item.date || '未标日期');
        const text = escHtml(item.replay_title || '打开回放');
        return item.replay_url
          ? `<div>${label}：<a href="${escHtml(item.replay_url)}" target="_blank" rel="noreferrer">${text}</a></div>`
          : `<div>${label}：${text}</div>`;
      }).filter(Boolean).join('')}</div>`
    : '';
  const clipExtra = primaryCutUrl || detail.entries.some(item => item.cut_link)
    ? `<div style="margin-top:10px; font-size:12px; color:#6271a8; line-height:1.7;">${[
        primaryCutUrl ? `<div>歌曲歌切：<a href="${escHtml(primaryCutUrl)}" target="_blank" rel="noreferrer">打开对应视频</a></div>` : '',
        ...detail.entries.map(item => {
          const entryCutUrl = getSongCutUrl(item.cut_link);
          if (!entryCutUrl || entryCutUrl === primaryCutUrl) return '';
          const label = escHtml(item.date || '未标日期');
          return `<div>${label}：<a href="${escHtml(entryCutUrl)}" target="_blank" rel="noreferrer">打开该次歌切</a></div>`;
        }).filter(Boolean)
      ].join('')}</div>`
    : '';
  dom.detailBody.innerHTML = `
    <table>
      <thead>
        <tr><th>演唱日期</th><th>演唱时间</th><th>状态</th></tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
    ${clipExtra}
    ${replayExtra}
  `;
}

function closeDetailModal() {
  dom.detailOverlay.classList.remove('show');
  dom.detailModal.classList.remove('show');
}

function syncFilterInputs() {
  dom.sortFieldSelect.value = state.songFilters.sortField;
  dom.sortDirSelect.value = state.songFilters.sortDir;
}

function parseNullableNumber(value) {
  const trimmed = String(value || '').trim();
  if (!trimmed) return null;
  const num = Number(trimmed);
  return Number.isFinite(num) ? num : null;
}

function applyFilterInputs() {
  state.songFilters.sortField = dom.sortFieldSelect.value;
  state.songFilters.sortDir = dom.sortDirSelect.value;
  syncPresetButtons();
  applySongFilters();
}

function resetSongFilters() {
  state.songFilters = {
    query: '',
    countMin: null,
    countMax: null,
    daysMin: null,
    daysMax: null,
    languages: [],
    tags: [],
    sortField: 'last_sing_at',
    sortDir: 'desc'
  };
  state.searchMode = 'mixed';
  dom.searchInput.value = '';
  syncSearchModeButtons();
  syncFilterInputs();
  syncPresetButtons();
  renderLanguageChips();
  renderTagChips();
  syncClearButton();
  applySongFilters();
}

function syncSearchModeButtons() {
  document.querySelectorAll('.search-mode-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.mode === state.searchMode);
  });
}

function syncClearButton() {
  dom.clearSearchBtn.classList.toggle('show', !!dom.searchInput.value);
}

// 按直播间切换主题：小松绿用橄榄绿主题 + 背景图；其他房间保持默认紫色风格
function applyRoomTheme(roomKey) {
  document.documentElement.classList.toggle('theme-xiaosonglu', roomKey === 'xiaosonglu');
}

async function chooseCurrentRoom(roomKey, forceRefreshSongs = false) {
  state.currentRoomKey = roomKey;
  state.currentRoom = getRoomConfig(roomKey);
  state.settings.lastRoomKey = roomKey;
  applyRoomTheme(roomKey);
  await saveGlobalSettings();

  dom.roomSelect.value = roomKey;
  renderRoomContextSummary();
  setFavoritesImportVisible(false);
  dom.favoritesImportInput.value = '';
  state.allSongs = [];
  state.filteredSongs = [];
  state.favoritesMap = {};
  state.favoriteList = [];
  state.songDataUpdatedAt = null;
  state.songDataFromCache = false;
  state.historyEntries = [];
  state.historyMeta = null;
  state.historySelectedDate = null;
  state.historyPage = 1;
  state.historyTotalPages = 1;
  deselectSong(true);
  state.detailsCache = {};
  renderSongs();
  renderFavorites();

  await Promise.all([
    loadCallwords(),
    loadFavorites()
  ]);

  await loadSongData(forceRefreshSongs);
  renderLanguageChips();
  renderTagChips();
  syncFilterInputs();
  syncPresetButtons();
  applySongFilters();
  await loadHistory(false);
}

function bindDom() {
  [
    'roomSelect','refreshBtn','headerStatus','sourceBadge','roomSubtitle','searchInput','clearSearchBtn','toggleFilterBtn','favoritesOnlyBtn','randomBtn',
    'songMetaText','songListWrap','filterCard','sortFieldSelect','sortDirSelect',
    'languageChips','tagChips','langAllBtn','langNoneBtn','tagAllBtn','tagNoneBtn','countPresetRow','daysPresetRow','resetFiltersBtn','actionPanel','selectedSongName','orderBtn','songPlayBtn',
    'clearSelectionBtn','historyYearSelect','historyMonthSelect',
    'historyDaySelect','historyPrevBtn','historyNextBtn','historyPageInfo','historyMetaText','historyListWrap','favoritesRefreshBtn',
    'favoritesToggleImportBtn','favoritesImportCard','favoritesImportInput','favoritesImportApplyBtn','favoritesImportCancelBtn','favoritesImportFileBtn','favoritesImportFileInput',
    'favoritesExportBtn','favoritesExportFileBtn','favoritesClearBtn','favoritesMetaText','favoritesCountText','favoritesListWrap',
    'callwordInput','saveCallwordBtn',
    'callwordListWrap','detailOverlay','detailModal','detailTitle','detailSub','detailBody','detailCloseBtn','toast'
  ].forEach(id => dom[id] = $(id));
}

function bindEvents() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(item => item.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.remove('active'));
      btn.classList.add('active');
      $(`tab-${btn.dataset.tab}`).classList.add('active');
    });
  });

  dom.roomSelect.addEventListener('change', async () => {
    await chooseCurrentRoom(dom.roomSelect.value, false);
  });

  dom.refreshBtn.addEventListener('click', async () => {
    await chooseCurrentRoom(state.currentRoomKey, true);
    showToast('已经重新刷新当前房间数据');
  });

  document.querySelectorAll('.search-mode-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.searchMode = btn.dataset.mode;
      syncSearchModeButtons();
      applySongFilters();
    });
  });

  dom.searchInput.addEventListener('input', () => {
    syncClearButton();
    applySongFilters();
  });

  dom.clearSearchBtn.addEventListener('click', () => {
    dom.searchInput.value = '';
    syncClearButton();
    applySongFilters();
    dom.searchInput.focus();
  });

  dom.toggleFilterBtn.addEventListener('click', () => {
    state.filtersVisible = !state.filtersVisible;
    dom.filterCard.style.display = state.filtersVisible ? 'block' : 'none';
    syncFilterSummary();
  });

  dom.favoritesOnlyBtn.addEventListener('click', () => {
    state.favoritesOnly = !state.favoritesOnly;
    applySongFilters();
  });

  dom.randomBtn.addEventListener('click', async () => {
    if (!state.allSongs.length) {
      showToast('当前歌单还是空的');
      return;
    }
    const available = state.allSongs.filter(song => !isLockedSong(song) && !isBannedSong(song));
    const base = available.length ? available : state.allSongs;
    const song = base[Math.floor(Math.random() * base.length)];
    selectSong(song);
    await doOrder();
  });

  [dom.sortFieldSelect, dom.sortDirSelect].forEach(el => {
    el.addEventListener('change', applyFilterInputs);
  });

  dom.languageChips.addEventListener('click', event => {
    const btn = event.target.closest('[data-lang-chip]');
    if (!btn) return;
    const lang = btn.dataset.langChip;
    if (state.songFilters.languages.includes(lang)) {
      state.songFilters.languages = state.songFilters.languages.filter(item => item !== lang);
    } else {
      state.songFilters.languages = [...state.songFilters.languages, lang];
    }
    renderLanguageChips();
    applySongFilters();
  });

  dom.tagChips.addEventListener('click', event => {
    const btn = event.target.closest('[data-tag-chip]');
    if (!btn) return;
    const tag = btn.dataset.tagChip;
    if (state.songFilters.tags.includes(tag)) {
      state.songFilters.tags = state.songFilters.tags.filter(item => item !== tag);
    } else {
      state.songFilters.tags = [...state.songFilters.tags, tag];
    }
    renderTagChips();
    applySongFilters();
  });

  // 次数/天数预设（事件委托）
  dom.countPresetRow.addEventListener('click', event => {
    const btn = event.target.closest('.preset-btn');
    if (!btn) return;
    state.songFilters.countMin = btn.dataset.countMin === '' ? null : Number(btn.dataset.countMin);
    state.songFilters.countMax = btn.dataset.countMax === '' ? null : Number(btn.dataset.countMax);
    syncFilterInputs();
    syncPresetButtons();
    applySongFilters();
  });

  dom.daysPresetRow.addEventListener('click', event => {
    const btn = event.target.closest('.preset-btn');
    if (!btn) return;
    state.songFilters.daysMin = btn.dataset.daysMin === '' ? null : Number(btn.dataset.daysMin);
    state.songFilters.daysMax = btn.dataset.daysMax === '' ? null : Number(btn.dataset.daysMax);
    syncFilterInputs();
    syncPresetButtons();
    applySongFilters();
  });

  // 语言 全选/全不选 = 不过滤（与网站语义一致）
  dom.langAllBtn.addEventListener('click', () => setLanguageChipsAll(true));
  dom.langNoneBtn.addEventListener('click', () => setLanguageChipsAll(false));

  // 标签 全选 = 只看这些标签；全不选 = 不过滤
  dom.tagAllBtn.addEventListener('click', () => {
    state.songFilters.tags = getTopTags();
    renderTagChips();
    applySongFilters();
  });
  dom.tagNoneBtn.addEventListener('click', () => {
    state.songFilters.tags = [];
    renderTagChips();
    applySongFilters();
  });

  dom.resetFiltersBtn.addEventListener('click', resetSongFilters);

  dom.songListWrap.addEventListener('click', async event => {
    // 播放按钮：播放/暂停单曲，并自动选中该歌曲（打开下方操作栏）
    const playBtn = event.target.closest('[data-play-song]');
    if (playBtn) {
      const song = state.filteredSongs.find(item => item.song_id === Number(playBtn.dataset.playSong));
      if (song) {
        selectSong(song);
        toggleSongPlay(song);
      }
      return;
    }

    const favoriteBtn = event.target.closest('[data-favorite-key]');
    if (favoriteBtn) {
      const songEl = favoriteBtn.closest('.song-item');
      const songId = Number(songEl && songEl.dataset.songId);
      const song = state.filteredSongs.find(item => item.song_id === songId);
      if (song) await toggleFavoriteBySong(song);
      return;
    }

    const detailBtn = event.target.closest('[data-detail-song]');
    if (detailBtn) {
      await loadSongDetail(detailBtn.dataset.detailSong, detailBtn.dataset.detailLabel, detailBtn.dataset.detailCount);
      return;
    }

    const cutLinkAnchor = event.target.closest('[data-song-cut-link]');
    if (cutLinkAnchor) {
      return;
    }

    const songEl = event.target.closest('.song-item');
    if (!songEl) return;
    const song = state.filteredSongs.find(item => item.song_id === Number(songEl.dataset.songId));
    if (song) selectSong(song);
  });

  dom.orderBtn.addEventListener('click', doOrder);
  dom.songPlayBtn.addEventListener('click', () => {
    if (state.selectedSong) toggleSongPlay(state.selectedSong);
  });
  dom.clearSelectionBtn.addEventListener('click', () => {
    stopPlay(); // 取消选中时自动停止播放
    deselectSong(false);
  });

  // 切换日期后直接加载对应日期的歌曲，无需再点"查看"
  dom.historyYearSelect.addEventListener('change', () => {
    fillHistoryMonthSelector();
    fillHistoryDaySelector();
    loadHistoryPage(1);
  });
  dom.historyMonthSelect.addEventListener('change', () => {
    fillHistoryDaySelector();
    loadHistoryPage(1);
  });
  dom.historyDaySelect.addEventListener('change', () => loadHistoryPage(1));
  dom.historyPrevBtn.addEventListener('click', () => loadHistoryPage(Math.max(1, state.historyPage - 1)));
  dom.historyNextBtn.addEventListener('click', () => loadHistoryPage(Math.min(state.historyTotalPages, state.historyPage + 1)));

  dom.historyListWrap.addEventListener('click', async event => {
    const btn = event.target.closest('[data-history-order]');
    if (!btn) return;
    const entry = state.historyEntries[Number(btn.dataset.historyOrder)];
    if (!entry) return;
    const text = `点歌 ${entry.song_name || ''}`;
    const ok = await sendToChatInput(text);
    if (ok !== false) showToast(`已填入：${text}`);
  });

  dom.favoritesRefreshBtn.addEventListener('click', renderFavorites);
  dom.favoritesToggleImportBtn.addEventListener('click', () => {
    setFavoritesImportVisible(!state.favoritesImportVisible);
  });
  dom.favoritesImportCancelBtn.addEventListener('click', () => setFavoritesImportVisible(false));
  dom.favoritesImportApplyBtn.addEventListener('click', () => importFavoritesFromText());
  dom.favoritesImportFileBtn.addEventListener('click', () => dom.favoritesImportFileInput.click());
  dom.favoritesImportFileInput.addEventListener('change', handleFavoriteFileImport);
  dom.favoritesExportBtn.addEventListener('click', exportFavorites);
  dom.favoritesExportFileBtn.addEventListener('click', exportFavoritesToFile);
  dom.favoritesClearBtn.addEventListener('click', clearFavorites);

  dom.favoritesListWrap.addEventListener('click', async event => {
    const removeBtn = event.target.closest('[data-favorite-remove-key]');
    if (removeBtn) {
      const key = removeBtn.dataset.favoriteRemoveKey;
      if (key && state.favoritesMap[key]) {
        delete state.favoritesMap[key];
        await saveFavorites();
        hydrateFavoriteList();
        applySongFilters();
      }
      return;
    }

    const orderBtn = event.target.closest('[data-favorite-order-key]');
    if (orderBtn) {
      const key = orderBtn.dataset.favoriteOrderKey;
      const snapshot = state.favoriteList.find(item => item.key === key);
      if (!snapshot) return;
      const liveSong = state.allSongs.find(item => getFavoriteKey(item) === key);
      if (liveSong) selectSong(liveSong);
      const text = `点歌 ${snapshot.display_song_name || snapshot.song_name || ''}`;
      const ok = await sendToChatInput(text);
      if (ok !== false) showToast(`已填入：${text}`);
      return;
    }

    const copyBtn = event.target.closest('[data-favorite-copy-key]');
    if (copyBtn) {
      const key = copyBtn.dataset.favoriteCopyKey;
      const snapshot = state.favoriteList.find(item => item.key === key);
      if (!snapshot) return;
      await copyToClipboard(snapshot.display_song_name || snapshot.song_name || '');
      showToast('已复制歌名');
    }
  });

  dom.saveCallwordBtn.addEventListener('click', addCallword);
  dom.callwordInput.addEventListener('keypress', event => {
    if (event.key === 'Enter') addCallword();
  });

  dom.callwordListWrap.addEventListener('click', async event => {
    const useBtn = event.target.closest('[data-callword-use]');
    if (useBtn) {
      await useCallword(Number(useBtn.dataset.callwordUse));
      return;
    }
    const delBtn = event.target.closest('[data-callword-del]');
    if (delBtn) {
      await deleteCallword(Number(delBtn.dataset.callwordDel));
    }
  });

  dom.detailOverlay.addEventListener('click', closeDetailModal);
  dom.detailCloseBtn.addEventListener('click', closeDetailModal);
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') closeDetailModal();
  });
}

async function init() {
  bindDom();
  bindEvents();
  populateRoomSelect();
  syncClearButton();
  syncSearchModeButtons();
  syncFilterInputs();

  await loadGlobalSettings();

  // 应用设置里的默认搜索模式与排序（chooseCurrentRoom 内部会按这些值过滤）
  state.searchMode = state.settings.defaultSearchMode || 'mixed';
  state.songFilters.sortField = state.settings.defaultSortField || 'last_sing_at';
  state.songFilters.sortDir = state.settings.defaultSortDir || 'desc';
  syncSearchModeButtons();
  syncFilterInputs();
  syncPresetButtons();

  const params = new URLSearchParams(location.search);
  const queryRoomKey = params.get('roomKey');
  const queryRoomId = params.get('roomId');
  if (params.get('embedded') === '1') {
    document.documentElement.classList.add('embedded');
  }

  state.activeTab = await getActiveTab();
  state.activeRoomContext = detectRoomFromUrl(state.activeTab && state.activeTab.url);
  if (!state.activeRoomContext.supported && queryRoomKey && ROOM_CONFIGS[queryRoomKey]) {
    state.activeRoomContext = {
      roomKey: queryRoomKey,
      roomId: queryRoomId || ROOM_CONFIGS[queryRoomKey].roomId,
      supported: true
    };
  }

  let initialRoomKey = state.settings.lastRoomKey || 'miting';
  if (state.activeRoomContext.supported) initialRoomKey = state.activeRoomContext.roomKey;
  if (!ROOM_CONFIGS[initialRoomKey]) initialRoomKey = 'miting';

  await chooseCurrentRoom(initialRoomKey, false);
  await loadAudioIndex();
  if (!state.activeRoomContext.supported) {
    setHeaderStatus('未在支持直播间内', 'warn');
  }
}

init().catch(error => {
  console.error('[歌单助手] 初始化失败:', error);
  if (!dom.headerStatus) return;
  setHeaderStatus('初始化失败', 'err');
  showToast(`初始化失败：${error.message}`);
});